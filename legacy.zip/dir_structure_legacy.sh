#!/bin/sh
#
# Copyright (C) 2017 Intel Corporation.  All Rights Reserved.
#
# The source code contained or described herein and all documents
# related to the source code ("Material") are owned by Intel Corporation
# or its suppliers or licensors.  Title to the Material remains with
# Intel Corporation or its suppliers and licensors.  The Material is
# protected by worldwide copyright and trade secret laws and treaty
# provisions.  No part of the Material may be used, copied, reproduced,
# modified, published, uploaded, posted, transmitted, distributed, or
# disclosed in any way without Intel's prior express written permission.
#.
# No license under any patent, copyright, trade secret or other
# intellectual property right is granted to or conferred upon you by
# disclosure or delivery of the Materials, either expressly, by
# implication, inducement, estoppel or otherwise.  Any license under
# such intellectual property rights must be express and approved by
# Intel in writing.
#

SCRIPT_DIR=`cd $(dirname "$BASH_SOURCE") && pwd -P`
IMPI_VERSION=`echo $(basename $SCRIPT_DIR)`
if [ $IMPI_VERSION = "mpi_2019" ]
then
    cd $SCRIPT_DIR
    if [ -d ./intel64/bin ] && [ -d ./intel64/etc ] && [ -d ./intel64/lib ] && [ -d ./intel64/include ]
    then
          ln -s intel64/bin bin64
          ln -s intel64/lib lib64
          ln -s intel64/include include64
          ln -s intel64/etc etc64
          cd intel64/lib
          ln -s release/libmpi.a libmpi.a
          ln -s release/libmpi.so.12 libmpi.so
          ln -s release/libmpi.so.12 libmpi.so.12
    else
        echo "Unexpected folder structure. Please make sure that installation was successful."
    fi
else
    echo "Please run the script from <installdir>/compilers_and_libraries_<version>.<update>.<package>/linux/mpi_2019/"
    exit 1
fi
